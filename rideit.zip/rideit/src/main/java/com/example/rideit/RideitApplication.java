package com.example.rideit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RideitApplication {

	public static void main(String[] args) {
		SpringApplication.run(RideitApplication.class, args);
	}

}
